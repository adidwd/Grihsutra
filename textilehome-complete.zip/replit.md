# TextileHome E-commerce Application

## Overview

TextileHome is a modern e-commerce application built for selling premium textiles including bedsheets, pillow covers, and table covers. The application features a React frontend with TypeScript, an Express.js backend, and uses Drizzle ORM for database operations. The UI is built with shadcn/ui components and styled with Tailwind CSS.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **State Management**: TanStack Query for server state management
- **Form Handling**: React Hook Form with Zod validation
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with TypeScript
- **Framework**: Express.js for REST API
- **Database**: PostgreSQL (configured for Neon serverless)
- **ORM**: Drizzle ORM for type-safe database operations
- **Session Management**: Client-side session ID stored in localStorage
- **Security**: Comprehensive protection suite with multi-layer defense

### Data Storage
- **Database**: PostgreSQL with Drizzle ORM
- **Tables**: Products and cart items with foreign key relationships
- **Development Storage**: In-memory storage implementation for development
- **Connection**: Neon serverless database connection

### Security Features
- **Multi-layer Protection**: 8 security middleware layers for comprehensive defense
- **Bot Detection**: Automatic blocking of automated tools, crawlers, and scrapers
- **Rate Limiting**: Progressive limits (30/min strict, 200/15min general, 15/5min cart, 10/min search)
- **DDoS Protection**: Request size limits and progressive IP blocking
- **Attack Prevention**: SQL injection, XSS, and CSRF protection
- **Intelligent Blocking**: Automatic IP banning after repeated violations
- **Honeypot Traps**: Fake endpoints to catch automated attacks
- **Security Monitoring**: Real-time status endpoint for threat tracking
- **Request Validation**: Header, content-type, and origin verification

## Key Components

### Product Management
- Product catalog with categories (bedsheets, pillow-covers, table-covers)
- Product search functionality
- Featured products display
- Category-based filtering and sorting
- Product details with image gallery support

### Shopping Cart
- Session-based cart management
- Add/remove/update cart items
- Real-time cart synchronization
- Cart persistence across browser sessions

### User Interface
- Responsive design with mobile-first approach
- Modal-based shopping cart
- Search modal with real-time results
- Navigation with active link highlighting
- Toast notifications for user feedback

### API Endpoints
- GET `/api/products` - All products
- GET `/api/products/featured` - Featured products
- GET `/api/products/category/:category` - Products by category
- GET `/api/products/search` - Product search (rate limited: 10/min)
- GET `/api/cart` - Cart items
- POST `/api/cart` - Add to cart (rate limited: 15/5min)
- PUT `/api/cart/:id` - Update cart item (rate limited: 15/5min)
- DELETE `/api/cart/:id` - Remove from cart (rate limited: 15/5min)
- GET `/api/security/status` - Security monitoring endpoint

## Data Flow

1. **Product Display**: Frontend fetches products from API endpoints using TanStack Query
2. **Cart Operations**: Cart actions trigger API calls with session ID headers
3. **State Management**: TanStack Query manages caching and synchronization
4. **User Feedback**: Toast notifications provide immediate feedback for user actions
5. **Routing**: Wouter handles client-side navigation without page reloads

## External Dependencies

### Frontend Dependencies
- React ecosystem (React, React DOM)
- Radix UI components for accessible UI primitives
- TanStack Query for server state management
- Wouter for routing
- React Hook Form for form handling
- Zod for schema validation
- Date-fns for date manipulation
- Lucide React for icons

### Backend Dependencies
- Express.js for server framework
- Drizzle ORM for database operations
- Neon serverless for PostgreSQL connection
- Zod for data validation

### Development Tools
- Vite for build tooling
- TypeScript for type safety
- Tailwind CSS for styling
- ESBuild for backend bundling

## Deployment Strategy

### Development
- Vite dev server for frontend with HMR
- TSX for backend development with auto-restart
- Environment variables for database configuration

### Production Build
- Frontend: Vite builds static assets to `dist/public`
- Backend: ESBuild bundles server code to `dist/index.js`
- Single process serves both API and static files

### Database
- Drizzle migrations in `./migrations` directory
- Schema defined in `shared/schema.ts`
- Push schema changes with `npm run db:push`

## Changelog
```
Changelog:
- July 02, 2025. Initial setup with in-memory storage
- July 02, 2025. Added PostgreSQL database with Drizzle ORM integration
- July 02, 2025. Migrated from in-memory storage to persistent database storage
- July 02, 2025. Added basic security middleware (Helmet, rate limiting)
- July 02, 2025. Seeded database with 20 sample products across 3 categories
- July 02, 2025. Implemented comprehensive security suite with 8-layer protection:
  * Bot detection and automated blocking
  * Progressive rate limiting (strict: 30/min, general: 200/15min, cart: 15/5min, search: 10/min)
  * SQL injection and XSS protection with request sanitization
  * CSRF protection with origin validation
  * IP blocking system with temporary and permanent bans
  * Honeypot traps for automated attacks
  * Request size limiting and content validation
  * Security monitoring endpoint for threat tracking
- July 02, 2025. Prepared comprehensive CI/CD and deployment setup:
  * GitHub Actions workflows for testing, security scanning, and deployment
  * Docker containerization with multi-stage builds and health checks
  * Production deployment scripts with database migration support
  * Comprehensive documentation (README, DEPLOYMENT, CONTRIBUTING)
  * Environment-aware security settings (development vs production)
  * Multiple deployment options (Docker, cloud platforms, traditional hosting)
```

## User Preferences
```
Preferred communication style: Simple, everyday language.
```